class Physics
{

    Entity entity;
    float X_Velocity;
    float Y_Velocity;
    float X_Drag;
    float Y_Drag;


    Physics(Entity e){
        this.entity = e;
    }

    void update(){
    }


}