class Body
{
    float xPosition;
    float yPosition;
    PShape shape;
    Entity entity;

    Body(Entity entity)
    {
        this.entity = entity;
    }

    Boolean hasCollided(ArrayList<Entity> e)
    {
        return false;
    }

    ArrayList<Float> getPosition()
    {
        return Array.asList(xPosition, yPosition);
    }


}