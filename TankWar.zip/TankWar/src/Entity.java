class Entity
{
    private Health health;
    private Body body;
    private View view;
    private Physics physics;

    Boolean destroyed;

    Entity target;

    Health getHealth()
    {
        return health;
    }

    Body getBody()
    {
        return body;
    }

    View getView()
    {
        return view;
    }

    Physics getPhysics()
    {
        return physics;
    }

    Boolean isDestroyed()
    {
        return destroyed;
    }

    void setHealth(Health h)
    {
        health = h;
    }

    void setBody(Body b)
    {
        body = b;
    }

    void setView(View v)
    {
        view = v;
    }

    void setPhysics(Physics p)
    {
        physics = p;
    }


    void destroy()
    {

    }

    void update()
    {

    }

    void render()
    {

    }



}